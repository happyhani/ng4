import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-introduction-advise',
  templateUrl: './introduction-advise.component.html',
  styleUrls: ['./introduction-advise.component.css']
})
export class IntroductionAdviseComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

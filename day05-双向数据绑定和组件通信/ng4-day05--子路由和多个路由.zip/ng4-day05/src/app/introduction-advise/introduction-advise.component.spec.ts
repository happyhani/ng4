import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IntroductionAdviseComponent } from './introduction-advise.component';

describe('IntroductionAdviseComponent', () => {
  let component: IntroductionAdviseComponent;
  let fixture: ComponentFixture<IntroductionAdviseComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IntroductionAdviseComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IntroductionAdviseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

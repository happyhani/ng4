import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-introduction-cn',
  templateUrl: './introduction-cn.component.html',
  styleUrls: ['./introduction-cn.component.css']
})
export class IntroductionCnComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

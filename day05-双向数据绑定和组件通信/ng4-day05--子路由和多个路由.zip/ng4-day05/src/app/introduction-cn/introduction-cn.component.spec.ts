import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IntroductionCnComponent } from './introduction-cn.component';

describe('IntroductionCnComponent', () => {
  let component: IntroductionCnComponent;
  let fixture: ComponentFixture<IntroductionCnComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IntroductionCnComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IntroductionCnComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

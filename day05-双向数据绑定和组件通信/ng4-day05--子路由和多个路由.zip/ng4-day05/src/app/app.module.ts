import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from "@angular/forms";
import {RouterModule,Routes} from "@angular/router"; //导入路由对象

import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { BooksComponent } from './books/books.component';
import { IntroductionCnComponent } from './introduction-cn/introduction-cn.component';
import { IntroductionEnComponent } from './introduction-en/introduction-en.component';
import { IntroductionAdviseComponent } from './introduction-advise/introduction-advise.component';
import { PermissionGuardGuard } from './guard/permission-guard.guard';



//路由配置
const   appRoutes:Routes=[
  {path:'home',component:HomeComponent},
  {
    path:'book/:bookName',
    component:BooksComponent,
    children:[
      {path:'',component:IntroductionCnComponent},
      {path:'en',component:IntroductionEnComponent}
    ],
    canActivate:[PermissionGuardGuard]
  },
  {path:'advise',component:IntroductionAdviseComponent,outlet:'luyou2'},
  {path:'',redirectTo:'/home',pathMatch:'full'}
];

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    BooksComponent,
    IntroductionCnComponent,
    IntroductionEnComponent,
    IntroductionAdviseComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    RouterModule.forRoot(appRoutes) //主模块中引入路由配置
  ],
  providers: [PermissionGuardGuard],
  bootstrap: [AppComponent]
})
export class AppModule { }

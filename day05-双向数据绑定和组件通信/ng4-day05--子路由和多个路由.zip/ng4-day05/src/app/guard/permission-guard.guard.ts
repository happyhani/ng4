import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs/Observable';

@Injectable()
export class PermissionGuardGuard implements CanActivate {
  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
    console.log('有访问权限');
    /**
     * 可以从本地缓存中读取用户信息,如果存在就允许访问,否则不允许访问
     */
    localStorage.setItem('user','Tom');
    if(localStorage.getItem('user')=='Tom'){
      return true;
    }else{
      console.log('请先登录系统!');
      return false;
    }
  }
}

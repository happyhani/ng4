import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-books',
  templateUrl: './books.component.html',
  styleUrls: ['./books.component.css']
})
export class BooksComponent implements OnInit {
  public book:Book;
  private isChinase :boolean;


  constructor(private activatedRout: ActivatedRoute) { }

  ngOnInit() {
    //普通方式传参快照获取方式
    //console.log(this.activatedRout.snapshot.queryParams['bookName']);
    //rest方式的快照方式获取
    this.book = new Book(this.activatedRout.snapshot.params['bookName']);

  }

}
export class  Book{
  public bookName:string;
  public author?:string;
  constructor(bookName:string){
    this.bookName= bookName;
  }
}
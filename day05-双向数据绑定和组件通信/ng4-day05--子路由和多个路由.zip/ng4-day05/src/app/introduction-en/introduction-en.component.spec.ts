import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IntroductionEnComponent } from './introduction-en.component';

describe('IntroductionEnComponent', () => {
  let component: IntroductionEnComponent;
  let fixture: ComponentFixture<IntroductionEnComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IntroductionEnComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IntroductionEnComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

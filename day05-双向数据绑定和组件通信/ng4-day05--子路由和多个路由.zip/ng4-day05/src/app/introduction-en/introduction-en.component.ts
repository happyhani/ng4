import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-introduction-en',
  templateUrl: './introduction-en.component.html',
  styleUrls: ['./introduction-en.component.css']
})
export class IntroductionEnComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';


import { AppComponent } from './app.component';


@NgModule({
  //声明包含的组件,指令和管道,此处指本模块包含一个跟组件AppComponent
  declarations: [
    AppComponent
  ],
  //声明本模块中需要的其他模块,
  imports: [
    BrowserModule    //浏览器模块
  ],
  //声明本模块需要的服务
  providers: [],
  //启动类
  bootstrap: [AppComponent] 
})
export class AppModule { }

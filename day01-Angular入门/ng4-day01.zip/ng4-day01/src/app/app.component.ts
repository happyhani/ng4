import { Component } from '@angular/core';
/**
 * 跟组件AppComponent
 * @Conmponent这部分称为装饰器.
 * 装饰器是TypeScript的语法特性,实际上是一个自定义函数,用于往类,函数中注入额外的信息,这些额外的信息实际上就是Angular核心概念--元数据
 * Angular中元数据主要以装饰器的函数参数指定!
 * 自己理解: 装饰器是Angular中的一个类,作用是可让通过参数的形式把js,html,css关联到一块!参数交元数据!
 */

/*通过装饰器@Component指定了选择器名称、模板URL和组件样式文件,@命令,表示Angular内置的指令类,学名装饰器
  装饰器类中的配置信息叫"元数据", 通过参数形式把js,css,html关联到一块!
*/
@Component({
  selector: 'app-root', //组件名,与跟目录下index.html中的<app-root>绑定
  templateUrl: './app.component.html', //html模板路径,如果不怕麻烦可以直接写html相关代码!  template:`<h1>代码</h1>`
  styleUrls: ['./app.component.css']//指定本组件的样式
})
export class AppComponent {
  /*本组件的模板文件app.component.html可以通过{{title}}读取类中属性值*/
  title = 'Angular干货';
} 
 /*

@Component({
  selector: 'app-root', //组件名 
  template:`
    <h1>项目名字:{{title}}</h1>
  `,
  styles:[`h1{color:red}`]
})
export class AppComponent {
  title = '淘宝';
}
*/
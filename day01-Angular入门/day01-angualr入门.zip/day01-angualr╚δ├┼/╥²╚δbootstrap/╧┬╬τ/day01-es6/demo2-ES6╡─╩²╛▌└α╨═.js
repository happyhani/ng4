//ES6所有数据类型
var isOK = true;
var num1 = 20; //书
/**
 * ""字符串
 * 反引号  `内容`,让内容 不换行,可嵌入表达式
 */
var age = 20;
var jieshao = "\u60A8\u597D,\u6211\u7684\u5E74\u9F84" + age;
console.log('介绍' + jieshao);
/**
 * 枚举类型,默认下标为0
 * 某个属性有固定取值时,可以使用枚举!
 */
var Color;
(function (Color) {
    Color[Color["Red"] = 0] = "Red";
    Color[Color["Green"] = 1] = "Green";
    Color[Color["Blue"] = 2] = "Blue";
})(Color || (Color = {}));
;
var yanSe01 = Color.Blue;
console.log('颜色:' + yanSe01);
/**
 * ES6中如果不确定哪种类型可以使用 any任意类型
 */
var arr1 = [1, 2, 3, 4];
var arr2 = [1, "aaa", 20.9];
//对象类型
var arr3 = [1, "aaa", 20.9];
console.log(arr2);
//console.log('取年龄值:'+age22);
/**
 * ES6新增空类型
 * 表示:该函数无返回结果!s
 */
function jia(num1, num2) {
    var jieguo = num1 + num2;
    console.log('结果' + jieguo);
}
// 错误,因为参数类型必须为 数字,jia("3",4);
jia(3, 4);

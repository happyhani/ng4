//ES6所有数据类型
let isOK:boolean = true;
let num1:number= 20; //书
/**
 * ""字符串
 * 反引号  `内容`,让内容 不换行,可嵌入表达式
 */
let age:number=20;
let jieshao:string=`您好,我的年龄${age}`;
console.log('介绍'+jieshao);
/**
 * 枚举类型,默认下标为0
 * 某个属性有固定取值时,可以使用枚举!
 */
enum Color{Red,Green,Blue};
let yanSe01:Color = Color.Blue;
console.log('颜色:'+yanSe01);
/**
 * ES6中如果不确定哪种类型可以使用 any任意类型
 */
let arr1=[1,2,3,4];
let arr2:any[] =[1,"aaa",20.9];
//对象类型
let arr3:Object[] =[1,"aaa",20.9];
console.log(arr2);

//console.log('取年龄值:'+age22);
/**
 * ES6新增空类型
 * 表示:该函数无返回结果!s
 */
function jia(num1:number,num2:number):void{
    let jieguo = num1+num2;
    console.log('结果'+jieguo);
}
// 错误,因为参数类型必须为 数字,jia("3",4);
jia(3,4);




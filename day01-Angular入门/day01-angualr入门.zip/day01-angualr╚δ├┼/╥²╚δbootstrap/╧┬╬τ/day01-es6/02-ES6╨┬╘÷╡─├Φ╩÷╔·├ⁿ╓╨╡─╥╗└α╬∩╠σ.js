/**
 * ES6新增
 * js代码描述生活中一类物体
 */
var Phone = /** @class */ (function () {
    function Phone() {
    }
    return Phone;
}());
//新建具体的某个手机
var zhangSan = new Phone();
zhangSan.id = 10001110;
zhangSan.xinghao = '苹果8';
zhangSan.price = 6000;
console.log('张三的手机型号:' + zhangSan.xinghao);

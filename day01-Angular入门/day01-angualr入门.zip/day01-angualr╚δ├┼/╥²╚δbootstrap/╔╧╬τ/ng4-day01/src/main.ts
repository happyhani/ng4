import { enableProdMode } from '@angular/core';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';

import { AppModule } from './app/app.module';
import { environment } from './environments/environment';

if (environment.production) {
  enableProdMode();
}

//bootstrapModule,指定启动的根模块名字!
platformBrowserDynamic().bootstrapModule(AppModule)
  .catch(err => console.log(err));

import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';


import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { MainComponent } from './main/main.component';
import { FooterComponent } from './footer/footer.component';


@NgModule({
  //声明当前项目组件依赖
  declarations: [
    AppComponent,
    HeaderComponent,
    MainComponent,
    FooterComponent  //根组件
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent] //启动根组件!
})
//根模块AppModule
export class AppModule { }

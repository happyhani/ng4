import { Component } from '@angular/core';
/**
 * @Component注解,标识这是angualr的一个组件类
 * app-root:跟组件
 */
@Component({
  selector: 'app-root', //组件名
  //网页,模板
  templateUrl: './app.component.html',
  //网页css文件
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = '111我的第一个Angular程序';
  title2 = 'aaaaa';
}

import { Component, OnInit } from '@angular/core';
import * as $ from 'jquery';

class User {
  id:number;
  name:string;
  age:number;
  email:string;
  address:any;
}
const USERLIST :User[]=[
  {id:1,name:'张三',age:20,email:'123@q.com',address:{province:'山东',city:'济南'}},
  {id:2,name:'李四',age:20,email:'123@q.com',address:{province:'山西',city:'太原'}},
  {id:3,name:'王五',age:20,email:'123@q.com',address:{province:'河南',city:'郑州'}}
];


@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {
  user:User= {id:10,name:'小明明',age:20,email:'123@q.com',address:{province:'山东',city:'济南'}};
  usres= USERLIST;
  
  constructor() { 
  }
  ngOnInit() {
    
    $('#btn1').click(function(){
      alert('aaa');
    });
  }
}

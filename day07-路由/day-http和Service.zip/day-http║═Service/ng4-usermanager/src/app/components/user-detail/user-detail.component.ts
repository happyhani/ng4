import { Component, OnInit } from '@angular/core';
import { ActivatedRoute,Params } from '@angular/router';
import { User } from '../../model/user';
import { UserService } from '../../services/user-service';
@Component({
  selector: 'app-user-detail',
  templateUrl: './user-detail.component.html',
  styleUrls: ['./user-detail.component.css']
})
export class UserDetailComponent implements OnInit {
  private id:string;//参数id
  private user:any;//保存根据id 查询的结果
  //注入动态路由对象,获取参数
  constructor(private activedRoute:ActivatedRoute,private useService:UserService) { 
    this.activedRoute.params.subscribe((params:Params)=>{
      console.log('详情id:');
      console.log(params);
      this.id= params.id;
   });
  }

  ngOnInit() {
    //根据id 获取数据
    this.useService.getById(this.id).subscribe((res)=>{
      console.log('api ById:');
      console.log(res);
      this.user= res;
    });
    
  }

}

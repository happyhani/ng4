import { Component, OnInit } from '@angular/core';
import * as $ from 'jquery';

//户对象
class User {
  id:number;
  name:string;
  age:number;
  email:string;
  address:any;
}
//初始化数据
const USERLIST :User[]=[
  {id:1,name:'张三',age:20,email:'123@q.com',address:{province:'山东',city:'济南'}},
  {id:2,name:'李四',age:20,email:'123@q.com',address:{province:'山西',city:'太原'}},
  {id:3,name:'王五',age:20,email:'123@q.com',address:{province:'河南',city:'郑州'}}
];


@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {
  //单个用户新,用户数组,爱好
  user:User= {id:10,name:'小明明',age:20,email:'123@q.com',address:{province:'山东',city:'济南'}};
  usres= USERLIST;
  hobbys:string[];
  isOK=false;
  isRemove=false;
  isShowEdit:boolean=false;
  
  //构造方法,用于往UesrComponent中注入依赖对象,不建议进行数据初始化
  constructor() {
    this.hobbys=['HTML','JavaScript','CSS'];
  }
  //核心的逻辑放在init中
  ngOnInit() {
  }

  //自动增加爱好
  addHobby(){
    this.hobbys.push('Angular');
    
  }
  //手动增加爱好
  addHobby2(str:string):void{
    var flag = false;
    for(let i=0;i<this.hobbys.length;i++){
      if(this.hobbys[i]==str.trim()){
        flag= true;
      }
    }
    if(flag==false){
      this.isOK= true;
      this.isRemove =false;
      this.hobbys.push(str);
    }else{
      this.isOK= false;
      this.isRemove =true;
    }
      
  }
  //编辑
  isShowEditUser(){
    this.isShowEdit = !this.isShowEdit;
  }
 
  //删除
  deleteUser(i){
    this.hobbys.splice(i,1);
  }

}

import { Component, OnInit } from '@angular/core';
import { UserService } from '../../services/user-service';


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
  providers:[UserService] //步骤2:引入服务
})
export class HomeComponent implements OnInit {
  //用户列表
  user={id:"",name:"",email:"",phone:""};
  users:any;
  isEdit:boolean=false;
  isShowDetail:boolean =false;
  //步骤3:构造方法中注入
  constructor(private userService:UserService) { 
      console.log(this.users);
  }

  ngOnInit() {
      //步骤4: 可以直接使用服务对象了!
      this.userService.getUsers().subscribe(res=>{
        console.log('apiGet:');
        console.log(res);
        this.users= res;
      });
  }

  /*控制层*/
  onSubmit(isEdit){
    if(isEdit){
      console.log('编辑');
      this.userService.updateUser(this.user).subscribe(res=>{
        console.log('编辑');
        console.log(res);
        //删除当前的
        for(let i=0;i<this.users.length;i++){
          if(this.users[i].id==this.user.id){
            this.users.splice(i,1);
          }
        }
        //添加更新的
        this.users.unshift(res);
      })
    }else{
      console.log('新增用户信息:');
      console.log(this.user);
      this.userService.addUser(this.user).subscribe(u=>{
        console.log('api返回结果:');
        console.log(u);
        this.users.unshift(u);
      })
    }
  }
  onDelete(id){
    this.userService.deleteUser(id).subscribe(res=>{
      console.log("api Delete:")
      console.log(res);
      for(let i=0;i<this.users.length;i++){
        if(this.users[i].id=id){
          this.users.splice(i,1);
        }
      }
    })
  }
  onEdit(user){
    this.isEdit = true;
    this.user = user;
  }


  /*详情:通过参数赋值:真实项目中只传id
  showDetail(u:User){
    //有数据传递过来时才为空
    this.isShowDetail = !this.isShowDetail;
    console.log('传递过来的用户信息:');
    console.log(u);
    this.user= u;
  }
  */
  /*事件跳转
  goDetail(str:string){
    alert('参数id值:'+str);
    this.router.navigate(['/detail',{id:1}])
  }
  */



}

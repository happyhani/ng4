//用户对象
export class User {
    /** 
    id:number;
    name:string;
    age:number;
    email:string;
    hobbys:string[];
    constructor(id:number,name:string,age:number,email:string,hobbys:string[]){
        this.id= id;
        this.name=name;
        this.age= age;
        this.email= email;
        this.hobbys= hobbys;
    }
*/
    //这是简写
    constructor(public id:number,private name:string,private age:number,private email:string,private phone:string) {}
}
//初始化数据
export const USERLIST:User[]=[
    new User(1,'AeiAei',20,'123@qq.com','123456'),
    new User(2,'BiBi',22,'123@qq.com','123456'),
    new User(3,'CeiCei',23,'123@qq.com','123456')
];
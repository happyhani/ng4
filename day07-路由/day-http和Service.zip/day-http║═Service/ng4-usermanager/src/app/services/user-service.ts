import { Injectable } from "@angular/core";
import { User, USERLIST } from "../model/user";
import { Http,Headers } from "@angular/http";
import 'rxjs/add/operator/toPromise';
import 'rxjs/add/operator/map';


/**
 * 组件和路由已经在view层实现代码解耦
 * 处理数据相关的业务逻辑应该从controller里分离,而Angular提供分离的方式就是service
 * 增,删除,修.查等逻辑代码可以放在service中,可以被其他对象或类注入
 */
@Injectable()
export class UserService {
    url:string="http://jsonplaceholder.typicode.com/users/";
    
    constructor(private http:Http){}
    //get 获取所有用户
    getUsers(){
      return this.http.get(this.url).map(res=>res.json());
    }
   
    getById(id){
        return this.http.get(this.url+id).map(res=>res.json());
    }
    addUser(user){
        return this.http.post(this.url,user).map(res=>res.json());
    }

    deleteUser(id){
        return this.http.delete(this.url+id).map(res=>res.json());
    }
    updateUser(user){
        return this.http.put(this.url+user.id,user).map(res=>res.json());
    }

}

import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from "@angular/forms";
import { RouterModule,Routes } from "@angular/router";
import { HttpModule} from "@angular/http";



import { AppComponent } from './app.component';
import { HomeComponent } from './components/home/home.component';
import { UserComponent } from './components/user/user.component';
import { NavbarComponent } from './components/navbar/navbar.component';
import { UserDetailComponent } from './components/user-detail/user-detail.component';
import { UserService } from './services/user-service';


/**
 * 1 下载
 * 2 导入路由模块
 * 3 路由配置
 * 4 展示路由
 */
const appRoutes: Routes = [
  { path: "", component: UserComponent },
  { path: "user", component: UserComponent }, //课堂演示案例,操作用户信息
  { path: "home", component: HomeComponent },
  { path: "detail/:id", component: UserDetailComponent },
  { path: "**", component: HomeComponent },
];
@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    UserComponent,
    NavbarComponent,
    UserDetailComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    RouterModule,
    RouterModule.forRoot(appRoutes),
    HttpModule   //http模块
  ],
  providers: [UserService],
  bootstrap: [AppComponent]
})
export class AppModule { }

//独立商品模块,所有京东商品操作相关的方法和属性都放在这!
export class  Product{
    //属性
    public name:string;//默认就是public
    private price:number; //(1)添加访问权限控制符号
    private count:number;//数量
    //(2)对外提供共有的访问和赋值的方法
    public setPrice(price:number){
        if(price<200){
            this.price=5000;
        }else{
            this.price =price;
        }
    }
    //添加给数量赋值的公有方法! 可添加判断
    public setCount(jiage:number){
        //判断
        if(jiage<0){
            this.count = 0;
        }
    }
  

    jieshao(){
        console.log(`商品名${this.name},价格:${this.price},商品的库存数量:${this.count}`);
   
} }
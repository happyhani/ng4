//商品列表页面对应js文件
import  {Product} from './shangPin';

//商品
let iphone6 = new Product();
iphone6.name='苹果6';
//iphone6.price =-6000;//安全漏洞:敏感资料,不能被其他模块修改为非法数据!
iphone6.setPrice(-6000); //调用共有的get**/set方法
iphone6.setCount(-60);//结果为0
iphone6.jieshao();
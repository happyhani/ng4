"use strict";
exports.__esModule = true;
//独立商品模块,所有京东商品操作相关的方法和属性都放在这!
var Product = /** @class */ (function () {
    function Product() {
    }
    //(2)对外提供共有的访问和赋值的方法
    Product.prototype.setPrice = function (price) {
        if (price < 200) {
            this.price = 5000;
        }
        else {
            this.price = price;
        }
    };
    //添加给数量赋值的公有方法! 可添加判断
    Product.prototype.setCount = function (jiage) {
        //判断
        if (jiage < 0) {
            this.count = 0;
        }
    };
    Product.prototype.jieshao = function () {
        console.log("\u5546\u54C1\u540D" + this.name + ",\u4EF7\u683C:" + this.price + ",\u5546\u54C1\u7684\u5E93\u5B58\u6570\u91CF:" + this.count);
    };
    return Product;
}());
exports.Product = Product;

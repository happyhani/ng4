"use strict";
exports.__esModule = true;
//如何使用用户模块功能!
//(2)导入模块
var User_1 = require("./User");
//使用
var zhangSan = new User_1.User();
zhangSan["delete"]('zhangsan');

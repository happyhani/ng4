//如何使用用户模块功能!
//(2)导入模块
// import {类名}  from '路径/文件名'; 文件名不带后缀
import {User} from './User';

//使用
let zhangSan = new User(); 
zhangSan.name = '张三';
zhangSan.imgURL ='img01.jpg';
zhangSan.delete('zhangsan');
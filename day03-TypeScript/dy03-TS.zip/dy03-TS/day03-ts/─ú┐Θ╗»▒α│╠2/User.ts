//保存关于用户列表操作,相关属性和功能
//(1)把类当模块导出!
export class User{
    name:string;//名字
    imgURL:string;//头型地址
    getUser(name:string){
        console.log('获得用户资料的功能...');
    }
    delete(name:string){
        console.log('用户模块,删除用户名的功能');
    }
}
"use strict";
exports.__esModule = true;
//保存关于用户列表操作,相关属性和功能
//(1)把类当模块导出!
var User = /** @class */ (function () {
    function User() {
    }
    User.prototype.getUser = function (name) {
        console.log('获得用户资料的功能...');
    };
    User.prototype["delete"] = function (name) {
        console.log('用户模块,删除用户名的功能');
    };
    return User;
}());
exports.User = User;

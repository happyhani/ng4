//构造函数可以简化对象的赋值
class Person{
    //属性:名字,性别,年龄
    name:string;
    sex:string;
    age:number;
    //带参构造函数.可以简化赋值
    constructor(name:string,sex:string,age:number){
        this.name = name;
        this.sex =sex;
        this.age = age;
    }
    sleep(){//功能:睡觉
        console.log(this.name+"**和小猪一样,就喜欢睡觉");
    }
}
let huanHuan = new Person("欢欢",'女',20);//使用构造简化赋值
huanHuan.sleep();
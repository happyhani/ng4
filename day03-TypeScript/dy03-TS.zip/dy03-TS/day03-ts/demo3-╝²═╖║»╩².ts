function sum(a,b){
    return a+b;
}

//(参数1,参数2)=>{方法体}
//案例
//定时器: setInterval(function(){.....},1000);
//简化
function tanKuang(){
    setInterval(()=>{console.log('aaa')},1000);
}
tanKuang();
//函数:参数为可选参数,或默认值  [了解]
function sum(num1:number,num2:number,num3?:number){
    console.log(num1+num2);
}
sum(1,2,3);//第3个值可以选择性传入值
sum(1,2);
//参数有默认值
function sum(num1:number=30,num2:number,num3?:number){
    console.log(num1+num2);
}


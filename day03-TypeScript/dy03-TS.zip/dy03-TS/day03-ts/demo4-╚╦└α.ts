//Persion类,描述人
//和ES6写法区别:必须定义属性,不能直接用this调用
class Persion{
    name:string;
    age:number;
    sex:string;
    phone:string;
    //方法:吃饭,睡觉,打豆豆
    chiFan(str:string){
        console.log("**"+this.name+"*,和小猫一样,就喜欢吃***"+str)
    }   
}
//创建对象    new 出来
let lili = new Persion(); 
//属性,逐一赋值
lili.name = '丽丽';
lili.age =20;
lili.sex ='女';
lili.chiFan('鱼');

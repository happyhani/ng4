//使用:相当于用户定义了一种新数据类型!  
var lele = {
    name: '乐乐',
    color: '白色',
    strain: '京巴'
};
console.log("名字" + lele.name);

//   let 变量名:类型 = 值;
//布尔
let isOK :boolean = false;//标准写法
let isOK2 = false;//js写法也支持
//数字
let num1 :number = 20;
//字符串
let subject:string ="Angualr";
let years:number =5;
let wores:string =  `新技术*${subject}*,已经流行*${years}*年了`;
//数组
let arr1: number[] = [1,2,3,4];//只能接受数字
//TS新增-->泛型  Array<数据类型>  泛指接收的参数只能为某个类型
let arr2 : Array<number> = [1,3,5,7,9];
//any表示任意类型
let arr3:Array<any> = [1,"3",5.0,true,9];

// 元组类型
let x :[string,number];
x = ['Angualr',25];
console.log(x[0]);

//枚举类型
/**
 * 变量值是多个,而且是不经常变化时,可以使用枚举
 * 枚举和数组类似.有默认的下标,从0开始,但是enum下标可自定义
 */
enum Color{red,blue,green};
enum Color2{Red=10,Green=11,Blue=12};
let hongse = Color.red;
let hongse2 =Color2.Red;
console.log('颜色:'+hongse);
console.log('颜色:'+hongse2);
/**
 * 空void类型,TS中语法,函数可以带参数类型和返回值类型的,
 * 当函数无返回值时可以用 空表示
 */
function sum(a,b){//js 实现求和
    return a+b;
}
function sum2(a:number,b:number):number{//TS中标准定义
    return a+b;
}
function f2():void{
    console.log("aaaa");
}


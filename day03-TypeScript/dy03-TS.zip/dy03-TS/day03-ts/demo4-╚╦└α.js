//Persion类,描述人
//和ES6写法区别:必须定义属性,不能直接用this调用
var Persion = /** @class */ (function () {
    function Persion() {
    }
    //方法:吃饭,睡觉,打豆豆
    Persion.prototype.chiFan = function (str) {
        console.log("**" + this.name + "*,和小猫一样,就喜欢吃***" + str);
    };
    return Persion;
}());
//创建对象    new 出来
var lili = new Persion();
lili.name = '丽丽';
lili.age = 20;
lili.sex = '女';
lili.chiFan('鱼');

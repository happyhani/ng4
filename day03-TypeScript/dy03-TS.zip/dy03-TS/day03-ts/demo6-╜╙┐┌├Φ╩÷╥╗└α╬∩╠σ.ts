//接口描述生活中的小狗
//接口名规范:I**,和类区分开
interface  IDog{
    //只包含各种属性:名字,颜色,品种
    name:string;
    color:string;
    strain:string;//种类
}
//使用:相当于用户定义了一种新数据类型!  
let lele:IDog={
    name:'乐乐',
    color:'白色',
    strain:'京巴'
};
console.log("名字"+lele.name);
import { Component, OnInit } from '@angular/core';
import { Product} from '../data/Product';

//注解(参数就是当前ts类和其他文件的关系)
@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {
  title :string ="用户展示页面";
  name:string = "小猫猫";
  sex:string ="女";
  age:number;
  address:any;
  hobbys:string[];
  p1:Product= new Product();
  //构造函数,可以做数据初始化
  constructor() {
     //商品
     this.p1.name = '洋娃娃';
     this.p1.count=1;
     this.hobbys=['吃','喝','玩'];
     this.age = 28;
     this.address ={
       province:'山西',
       city:'太原'
     }
   }

  ngOnInit() {
  }

}

//用户自己创建的对象信息,也可以用{{}}展示到页面
export class  Product{
    name:string;
    price:number;
    count:number;

}
export class User{
    
}
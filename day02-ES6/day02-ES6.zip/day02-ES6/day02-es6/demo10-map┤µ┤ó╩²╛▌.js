//生活中很多成对的数据
//比如 cn-->中国,USA->美国,JP-->日本
//ES6新增Map存储key:value对
//创建
let map1 = new Map([
    ['CN','中国'],
    ['USA','美国'],
    ['JP','日本']
]);
console.log(map1);
//长度属性
console.log('长度:'+map1.size);
//根据名字获取值
console.log(map1.get('CN'));
//根据名字删除值
map1.delete('JP');
console.log('删除后的大小:'+map1.size);
//根据key名字判断
console.log('是否包含:'+map1.has('JP'));


//遍历所有的名字
for(let k of map1.keys()){
    console.log('名字:'+k);
}
//遍历所有值
for(let v of map1.values()){
    console.log('值:'+v);
}
//遍历每对数据
for(let item of map1.entries()){
    console.log(item[0],item[1]);
}
// 解构
for(let [key,v] of map1){
    console.log('解构语法获取名:'+key+"值:"+v);
}






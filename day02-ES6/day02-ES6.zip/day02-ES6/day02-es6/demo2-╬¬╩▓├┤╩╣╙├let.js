//(1)var变量,经常内层值把外层值覆盖!
//(2)for循环中var定义变量泄露为全局变量

//(1)
var name = 'tom';//全局
while(true){
    var name = 'KaiTe';//全局变量
    console.log(name);
    break;
}
console.log(name);//想用Tom,结果为 kaike
//解决
let name2 = 'tom';
while(true){
    let name2 = 'KaiTe';
    console.log(name2);//kaite
    break;
}
console.log(name2);//tom

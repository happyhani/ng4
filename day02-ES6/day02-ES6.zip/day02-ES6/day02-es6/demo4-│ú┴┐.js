//常量一般都大写! [规范]
const  PI = 3.1325926;
const SEX_MAN='男';
const SEX_WOMAN='女';

console.log(PI);
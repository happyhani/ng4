//set存储不重复的数据
// 新建
let s1= new Set();
//增加
s1.add(1);
s1.add(1);
s1.add(2);
console.log(s1.size);
//新建时直接赋值
let s2 = new Set([1,2,3]);
console.log('s2集合的内容:'+s2+"长度:"+s2.size);
//增加:可连写
s2.add('a').add('b').add('c');
console.log('增加完后的长度:'+s2.size);
//删除
s2.delete('a');
console.log('删除后的数据:'+s2.size);
//判断是否包含,返回boolean
console.log('是否包含:'+s2.has('zzy'));
//清空
s2.clear();
console.log('清空后大小:'+s2.size);
//遍历
let s3 = new Set(['red','blue','green']);
//方法1: for  of
for(let item of s3){
    console.log('每个值:'+item);
}
//方法2:当成成对的数据被解析
//{名:值} 名和值相同,{red:'red'}
s3.forEach((key,value)=>
{console.log('名字:'+key+"-->值"+value)});
//编列方法3:{red:'red',blue:blue,green:'green'}
for(let item of s3.keys()){
    console.log('值:'+item);
}
for(let item of s3.values()){
    console.log('值:'+item);
}





// 演示鸟类,直接复用 动物类的属性和方法
class Animal{
    //属性
    constructor(name,color,weight){
        this.name = name;
        this.color= color;
        this.weight = weight;
    }
    //介绍
    jieShao(){
        console.log(`我叫${this.name},我的毛是${this.color},体重:${this.weight}`);
        
    }
}
//鸟
class Bird extends Animal{
    
}
//复用方法
let yingWu = new Bird();
yingWu.name ='五彩金刚小钢炮';
yingWu.color='红色';
yingWu.weight ="10斤";
yingWu.jieShao();

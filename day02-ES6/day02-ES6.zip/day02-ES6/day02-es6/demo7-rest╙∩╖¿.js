//rest 语法指定函数参数
//函数简化接收参数个数
function f1(...name){
    console.log(name);
}
var f1 = (...name)=> name;
f1('zhangsan','lisi','wangwu');

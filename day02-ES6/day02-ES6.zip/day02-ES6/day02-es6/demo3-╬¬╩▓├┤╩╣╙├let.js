// for循环中i变量泄露为全局变量

var arr1 =[];
for(var i=1;i<=10;i++){
    arr1[i]=function(){
        console.log(i);
    }
}
//想要的结果6
arr1[6]();

let arr2 =[];
for(let i=1;i<=10;i++){
    arr2[i]=function(){
        console.log(i);
    }
}
//想要的结果6
arr2[6]();

//应用tab切换
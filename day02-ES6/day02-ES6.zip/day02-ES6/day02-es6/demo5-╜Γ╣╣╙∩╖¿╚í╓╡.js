//解构语法:
let a=1;
let b=2;
let c=3;
//ES6简写必须名字和值一一对应
let [a1,b1,c1]= [1,2,3]; 
console.log(a1);
console.log(b1);
let [d1,d2,d3,d4]= 'abcd';
console.log(d4);
//解构 对象
//let {name,sex}={name:'张三',sex:'男',age:20};
//let {name}={name:'张三',sex:'男',age:20};
//console.log(name);
//解构语法 获取长度
let {length: changDu}="hello";
console.log(changDu);
//解构用在函数中,返回多个值
function f1(){
    return [10,20,30];
}
let [x1,x2,x3]=f1();
console.log(x1);
// 交换变量值   
let y1= 1;
let y2= 2;
[y1,y2]= [y2,y1];
console.log('交换完后:y1:'+y1);
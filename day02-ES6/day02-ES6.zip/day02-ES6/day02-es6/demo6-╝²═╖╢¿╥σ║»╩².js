// ES6中允许使用=>定义函数
var f1 =function(num){
    return num;
}
console.log(f1(10));
//简写 (参数1,参数2,...) => 函数体
var f2= num => num;
console.log(f2(20));
var sum = (num1,num2)=> num1+num2;
console.log("和:"+sum(4,6));
//如果参数较多建议加上(参1,参2)
//如果方法体中代码较多,加上 {}
var sum2 = (num1,num2)=>{ num1+num2};


console.log('tab的js切换效果');
//获取4个菜单
/**
 * 问题:i泄露为全局变量
 * var声明的i在全局范围有效!
 * 所以每次循环,新的i值会覆盖原来的i值!
 * */ 
var btn = document.getElementsByClassName('btn');
for(let i=0;i<btn.length;i++){
    //let定义的i在当前块有效,没循环一次产生一个新变量
    btn[i].onclick=function(){
        console.log("您点的是:"+i);
    }
}
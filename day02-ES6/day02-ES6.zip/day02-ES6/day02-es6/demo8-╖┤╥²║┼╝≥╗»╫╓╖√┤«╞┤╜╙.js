// 字符串拼接
let name = '张三';
let age = 20;
let jieshao = "我叫*"+name+"*名字,我今年*"+age+"*岁了";
//ES6新增  字符串模板,反引号,可引入变量
let jieshao2 =`我叫*${name}**名字,今年*${age}*岁了`;
console.log(jieshao2);
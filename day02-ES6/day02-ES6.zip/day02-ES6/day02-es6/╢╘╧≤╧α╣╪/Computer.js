//描述生命中的电脑类
//建议类名大写! 比如:数组 Array
class Computer{
    //属性:品牌,价格,颜色...
    //构造函数,作用接收参数,为当前对象属性赋值!
    constructor(pinpai,price,color){
        //当前对象/类的属性 this.属性名= 传过来的值!
        this.pinpai =pinpai;
        this.price = price;
        this.color = color;
    }//功能:看电影,打游戏,聊天....编程
    movie(){
        //this表示 "当前对象"
        console.log("正在用**"+this.pinpai+"*品牌,*"
        +this.color+"*颜色的电脑看电影");
    }
}
//创建
let zzyC = new Computer('联想',1000,'黑色');
zzyC.movie();//打点调用
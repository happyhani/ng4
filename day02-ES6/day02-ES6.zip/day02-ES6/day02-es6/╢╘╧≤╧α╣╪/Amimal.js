class Animal{
    constructor(n1,t){//构造方法,完成2个属性的数据的初始化
        this.name= n1;
        this.type= t;
    }
    //吃
    chi(str){
        console.log("我叫*"+this.name+"**,*"+str+"*真好吃")
    }
}
let an01 = new Animal('豆豆','小猫');
an01.chi('鱼');
//狗,也是动物,可通过继承,直接复用 动物类代码!
class Dog extends Animal{
    //构造
    constructor(name,type,color){
        super(name,type); //super表示父类构造()
        this.color=color;
    }
}
let huanHuan = new Dog("欢欢","藏獒");
huanHuan.chi("骨头");// 直接继承的父类的功能!
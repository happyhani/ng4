//js变量作用范围2种:全局作用域,函数作用域
//es6新增块级作用域
//let关键字定义变量,范围是当前块!
{
    let a=3;
    var b=4;
    console.log(a);
}
console.log(a);